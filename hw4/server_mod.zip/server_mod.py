import os
import cv2
import json
import time
import socket, threading
import numpy as np
from hdfs import InsecureClient
from hdfs import util
from detect_opencv import detect
from Extraction import LicencePlateDetector as altdetect


def recvall(sock, count):
    buf = b''
    while count:
        newbuf = sock.recv(count)
        if not newbuf: return None
        buf += newbuf
        count -= len(newbuf)
    return buf


class DetectClient:

    def __init__(self, data_path = None):
        if data_path == None:
            self.data_path = r'./config/connect_info.json'
        else:
            assert type(data_path) == str
            self.data_path = data_path
        if not os.path.exists(self.data_path):
            self.data_path = r'./connect_info.json'

        with open(self.data_path) as data_file:
            data = json.load(data_file)
            self.hdfs_client = InsecureClient(url = 'http://' + data['namenode_url'] + ':' + str(data['port']), user = data['user'], root = data['root_path'])
            self.img_dir = data['img_dir']

        if self.img_dir[-1] != '/':
            self.img_dir += '/'
        else:
            pass
        
        self.file_name = 1
    
    def InitImgDir(self):
        try:
            list_rslt = self.hdfs_client.list(self.img_dir)
            if len(list_rslt) > 0:
                for name in list_rslt:
                    file_path = self.img_dir + name
                    self.hdfs_client.delete(file_path)

        except util.HdfsError:
            self.hdfs_client.makedirs(self.img_dir)

        return True

    def DataProcess(self, data, append = False, file_name = None):
        assert type(data) == str
        if file_name == None:
            file_name = self.img_dir + str(self.file_name)
        else:
            assert(type(file_name)) == str
        print("start writing...")
        start = time.time()
        self.hdfs_client.write(file_name, data, overwrite = True,  replication = 1, append = append)
        delta = time.time() - start
        print("writing complete, time delta is " + str(delta))
        return True

    def UploadVideo(self, vdo_path, threads = 2):
        self.hdfs_client.upload(hdfs_path = self.img_dir[:-1], local_path = vdo_path, n_threads = threads, overwrite = True)
        return 0
class Detector:

    def __init__(self, conn_sk, root_file_name, reinit = False):
        self.conn = conn_sk
        self.hdfs_client = DetectClient()
        if reinit:
            self.hdfs_client.InitImgDir()
        else:
            pass
        self.current_img_name = 1
        self.root_name = root_file_name + "_"
    
    def Detect(self, alter = True):
        with self.conn:
            file_name = self.conn.recv(6).decode() # Demo will always be 6 bytes
            print("File name: ",file_name)
            starter = 0
            frame_count = 1
            frame_array = []
            img_arr = []
            while True:
                stime = time.time()
                length = self.conn.recv(16)
                if not length:
                    break
                stringData = recvall(self.conn, int(length))
                if not stringData:
                    break
                data = np.frombuffer(stringData, dtype="uint8")
                decimg = cv2.imdecode(data, 1)
                print("start detecting...")
                start = time.time()
                if(alter == False):
                    have_lic = detect(decimg)
                else:
                    have_lic = altdetect(decimg)
                delta = time.time() - start
                print("end detecting with delta " + str(delta))
                if(have_lic):
                    img_arr.append(decimg)
                    frame_array.append(frame_count)
                    #self.hdfs_client.DataProcess(str(stringData), file_name = str(self.current_img_name))
                    #self.current_img_name += 1
                    print(self.current_img_name)
                    if len(img_arr) >= 600:
                        # save it to video
                        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
                        parent_dir = os.path.split(os.path.split(os.path.abspath(__file__))[0])[0]
                        video_path = os.path.join(parent_dir, "processed_video", self.root_name + str(starter) + ".mp4")
                        out = cv2.VideoWriter(video_path, fourcc, 60, (1280, 720))
                        for img in img_arr:
                            out.write(img)
                        out.release()
                        img_arr = []
                        starter += 1
                        self.hdfs_client.UploadVideo(video_path)
                    # print("Licence Plate Detected.")
                    else:
                        pass
                else:
                    # store frame array to video if exist
                    pass
                    # print("There is no Licence Plate.")
                # print("Time per frame: ", time.time() - stime)
                frame_count += 1
            if len(img_arr) > 0:
                fourcc = cv2.VideoWriter_fourcc(*'mp4v')
                parent_dir = os.path.split(os.path.split(os.path.abspath(__file__))[0])[0]
                video_name = os.path.join(parent_dir, "processed_video", self.root_name + str(starter) + ".mp4")
                out = cv2.VideoWriter(video_name, fourcc, 60, (1280, 720))
                for img in img_arr:
                    out.write(img)
                out.release()
                img_arr = []
                self.hdfs_client.UploadVideo(video_name)
            filename = file_name.split(".")[-2]
            file_name = 'tst_rslt'

            while os.path.exists(filename):
                tmp_int = 0
                filename = filename + str(tmp_int)
                tmp_int += 1

            parent_dir = os.path.split(os.path.split(os.path.abspath(__file__))[0])[0]

            rslt_path = os.path.join(parent_dir, "tst_rslt")
            rslt_path = os.path.join(rslt_path, str(self.root_name)+".txt")

            f = open(rslt_path, "w")
            f.close()
            f = open(rslt_path, "a")
            for frame in frame_array:
                f.write(str(frame)+'\n')
            f.close()
            self.hdfs_client.UploadVideo(rslt_path)


class ClientThread(threading.Thread):
    def __init__(self,clientAddress,clientsocket, client_num):
        threading.Thread.__init__(self)
        self.csocket = clientsocket
        self.caddr = clientAddress
        if client_num == 1:
            self.detector = Detector(self.csocket, str(client_num), True)
        else:
            self.detector = Detector(self.csocket, str(client_num))
        print ("New connection added: ", clientAddress)
    def run(self):
        print ("Connection from : ", self.caddr)
        self.detector.Detect(True)
        print ("Client at ", self.caddr , " disconnected...")

def main():
    LOCALHOST = "127.0.0.1"
    PORT = 8080
    client_number = 0
    MAX_CLIENT = 15

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((LOCALHOST, PORT))
    print("Server started")
    print("Waiting for client request..")

    while True:
        print("Listening")
        server.listen(1)
        clientsock, clientAddress = server.accept()
        while client_number >= MAX_CLIENT:
            pass
        client_number += 1
        newthread = ClientThread(clientAddress, clientsock, client_number)
        newthread.start()


if __name__ == "__main__":
    main()