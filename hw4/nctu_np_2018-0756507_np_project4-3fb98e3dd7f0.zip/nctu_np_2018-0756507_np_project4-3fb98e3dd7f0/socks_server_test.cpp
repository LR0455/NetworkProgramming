#include <array>
#include <boost/asio.hpp>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <utility>
#include <fstream>
#include <string>
#include <boost/algorithm/string.hpp>

using namespace std;
using namespace boost::asio;

io_service global_io_service;

int ssend = 0;
int rrecv = 0;

class Session : public enable_shared_from_this<Session> {
 private:
  enum { max_length = 1024 };
  int _flag = 0;
  unsigned char _VN, _CD;
  unsigned int _DST_PORT, _DST_IP;
  string _dst_ip_str;
  string _USER_ID;
  ip::tcp::socket _src_socket, _dst_socket;
  ip::tcp::acceptor _acceptor;
  string _src_ip, _src_port;
  boost::asio::streambuf _sock_rpy, _sock_req;
  ip::tcp::endpoint _dst_ep;
  array<char, 8> _package;
  array<char, max_length> _src_data, _dst_data;
  ifstream infile;
  vector<string> fire_c, fire_b;
  map<string, int> blacklist;

 public:
  Session(ip::tcp::socket socket): 
    _src_socket(move(socket)),
    _dst_socket(global_io_service),
    _acceptor(global_io_service, ip::tcp::endpoint(ip::tcp::v4(), 0)),
    _src_ip(_src_socket.remote_endpoint().address().to_string()),
    _src_port(to_string(_src_socket.remote_endpoint().port())) {}

  void start() {
    infile.open("socks.conf", ifstream::in);
    if (infile.good()) {
	set_firewall();
    }
    do_read_req();
  }

 private:
  void set_firewall() {
    string fire;
    vector<string> tmp;
    while(getline(infile, fire)) {
        boost::split(tmp, fire, boost::is_any_of(" "));
        if (tmp[1] == "b") {
            fire_b.push_back(tmp[2]);
        }
        else if (tmp[1] == "c") {
            fire_c.push_back(tmp[2]);
        }
    }
  }

  void do_read_req() {
    auto self(shared_from_this());
    async_read_until(
        _src_socket, _sock_req, '\0',
        [this, self](boost::system::error_code ec, size_t length) {
          if (!ec) {
            string str((istreambuf_iterator<char>(&_sock_req)), std::istreambuf_iterator<char>() );
            _VN = str[0];
            _CD = str[1];
            _DST_PORT = ((unsigned char)str[2] << 8) | (unsigned char)str[3];
            _DST_IP = (unsigned char)str[4] << 24 | (unsigned char)str[5] << 16 | (unsigned char)str[6] << 8 | (unsigned char)str[7];
            ip::address_v4 v4(_DST_IP);
            _dst_ip_str = v4.to_string();
            _USER_ID = str.substr(8);
            cout << "<S_IP>: " << _src_ip << endl;
            cout << "<S_PORT>: " << _src_port << endl;
            if (_CD == 1) {
                cout << "<D_IP>: " << _dst_ip_str << endl;
                cout << "<D_PORT>: " << _DST_PORT << endl;
                cout << "<COMMAND>: CONNECT" << endl;
                do_send_reply();
            }
            if (_CD == 2) {
                cout << "<D_IP>: 0" << endl;
                cout << "<D_PORT>: 0" << endl;
                cout << "<COMMAND>: BIND" << endl;
                do_send_reply();
                do_accept();
            } 
          }
          else {
            cout << ec.message() << endl;
          }
        });
  }

  void do_accept() {
    auto self(shared_from_this());
    _acceptor.async_accept(_dst_socket, [this, self](boost::system::error_code ec) {
      if (!ec) {
        _flag = 1;
        do_send_reply();
      }
    });    
  }

  void do_send_reply() {
    auto self(shared_from_this());
    _package[0] = 0;
    _package[1] = (unsigned char) 91;

    vector<string> a, b;
        if (_CD == 1 && fire_c.size() != 0) {
            for (int i = 0; i < fire_c.size(); i ++) {
                boost::split(a, fire_c[i], boost::is_any_of("."));
                boost::split(b, _dst_ip_str, boost::is_any_of("."));
		for (int j = 0; j < 4; j++) {
		    cout << "aj: " << a[j] << endl;
                    if (a[j] == "*") {
                        _package[1] = (unsigned char) 90;
                        break;
                    }
                    else {
                        if (a[j] != b[j])
                            break;
                    }
                }
            }
        }
        if (_CD == 2 && fire_b.size() != 0) {
            for (int i = 0; i < fire_b.size(); i ++) {
                boost::split(a, fire_b[i], boost::is_any_of("."));
                boost::split(b, _dst_ip_str, boost::is_any_of("."));
                for (int j = 0; j < 4; j++) {
                    if (a[j] == "*") {
                        _package[1] = (unsigned char) 90;
                        break;
                    }
                    else {
                        if (a[j] != b[j])
                            break;
                    }
                }
            }
        }

    map<string, int>::iterator it = blacklist.find(_src_ip);
    if (it == blacklist.end()) {
        blacklist.insert(pair<string, int>(_src_ip, 1));
    } else {
        if (it->second == 3) {
            _package[0] = (unsigned char) 91;
        } else {
            it->second ++;
        }
    }

    if (_CD == 1) {
        _package[2] = _DST_PORT / 256;
        _package[3] = _DST_PORT % 256;
        _package[4] = _DST_IP >> 24;
        _package[5] = _DST_IP >> 16 & 0xff;
        _package[6] = _DST_IP >> 8 & 0xff;
        _package[7] = _DST_IP & 0xff;
        async_write(
            _src_socket, buffer(_package, 8),
            [this, self](boost::system::error_code ec, std::size_t length) {
            if (!ec) {
                do_connect();
            }
            });
    }
    else if (_CD == 2) {
        _package[2] = _acceptor.local_endpoint().port() / 256;
        _package[3] = _acceptor.local_endpoint().port() % 256;
        _package[4] = 0;
        _package[5] = 0;
        _package[6] = 0;
        _package[7] = 0;
        async_write(
            _src_socket, buffer(_package, 8),
            [this, self](boost::system::error_code ec, std::size_t length) {
            if ((!ec) && (_flag != 0)) {
                read_from_src_sock();
                read_from_dst_sock();
            }
            });
    }
  }

  void do_connect() {
    auto self(shared_from_this());
    ip::address_v4 v4(_DST_IP);
    ip::address addr(v4);
    ip::tcp::endpoint dst_ep(addr, _DST_PORT);
    _dst_ep = dst_ep;
    _dst_socket.async_connect(
        _dst_ep, 
        [this, self](boost::system::error_code ec) {
           if (!ec) {
            read_from_src_sock();
            read_from_dst_sock();
           } 
        });
  }

  void read_from_src_sock() {
    auto self(shared_from_this());
     _src_socket.async_read_some(
        buffer(_src_data, max_length),
        [this, self](boost::system::error_code ec, std::size_t length) {
            if (!ec) {
                rrecv += length;
                write_to_dst_sock(length);
            }
            else {
                _dst_socket.close();
                _src_socket.close();
                cout << ec.message() << endl;
            }
        });
  }

  void read_from_dst_sock() {
    auto self(shared_from_this());
     _dst_socket.async_read_some(
         buffer(_dst_data, max_length),
        [this, self](boost::system::error_code ec, std::size_t length) {
            if (!ec) {
                write_to_src_sock(length);
            }
            else {
                _dst_socket.close();
                _src_socket.close();
                cout << ec.message() << endl;
            }
    });
    
  }

  void write_to_src_sock(size_t len) {
    auto self(shared_from_this());
    async_write(
        _src_socket, buffer(_dst_data, len),
        [this, self](boost::system::error_code ec, std::size_t length) {
            if (!ec) {
                read_from_dst_sock();
            }
            else {
                _dst_socket.close();
                _src_socket.close();
                cout << ec.message() << endl;
            }
    });
  }
  
  void write_to_dst_sock(size_t len) {
    auto self(shared_from_this());
    async_write(
        _dst_socket, buffer(_src_data, len),
        [this, self](boost::system::error_code ec, std::size_t length) {
            if (!ec) {
                ssend += length;
                read_from_src_sock();
            }
            else {
                _dst_socket.close();
                _src_socket.close();
                cout << ec.message() << endl;
            }
    });
  }

};

class Server {
 private:
  ip::tcp::acceptor _acceptor;
  ip::tcp::socket _socket;

 public:
  Server(short port)
      : _acceptor(global_io_service, ip::tcp::endpoint(ip::tcp::v4(), port)),
        _socket(global_io_service) {
    do_accept();
  }

 private:
  void do_accept() {
    _acceptor.async_accept(_socket, [this](boost::system::error_code ec) {
      if (!ec) make_shared<Session>(move(_socket))->start();

      do_accept();
    });
  }
};

int main(int argc, char* const argv[]) {
  if (argc != 2) {
    cerr << "Usage:" << argv[0] << " [port]" << endl;
    return 1;
  }

  try {
    unsigned short port = atoi(argv[1]);
    Server server(port);
    global_io_service.run();
  } catch (exception& e) {
    cerr << "Exception: " << e.what() << "\n";
  }

  return 0;
}
