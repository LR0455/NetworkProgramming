#include <unistd.h>
#include <iostream>
#include <string>
#include <array>
#include <boost/asio.hpp>
#include <boost/algorithm/string/replace.hpp>
#include <cstdlib>
#include <memory>
#include <utility>
#include <string>
#include <fstream>

using namespace std;
using namespace boost::asio;

io_service global_io_service;

void escape(string &s);
void output_shell(string s, string c);
void output_command(string s, string c);

class Session: public enable_shared_from_this<Session> {
    private:
        ifstream _infile;
        enum { max_length = 1024 };
        array<char, max_length> _data;
        array<char, 10> _package;
        string _host, _port, _file;
        string _send_msg;
        string _sock, _sock_port;
        int _num;
        ip::tcp::resolver::iterator _endpoint_iterator;
        ip::tcp::socket _socket;
    public:
        Session(string host, string port, string file, int num, string sock, string sock_port)
            : _host(host), _port(port), _file(file), _num(num), _socket(global_io_service), _sock(sock), _sock_port(sock_port) {
                _infile.open("test_case/" + _file);
                cout << strerror(errno) << endl;
            }
        void start() {
            do_dst_resolve();
        }
    private:
        void do_package() {
            _package[0] = 4;
            _package[1] = 1;
            _package[2] = stoi(_port) / 256;
            _package[3] = stoi(_port) % 256;
            _package[4] = _endpoint_iterator->endpoint().address().to_v4().to_ulong() >> 24;
            _package[5] = _endpoint_iterator->endpoint().address().to_v4().to_ulong() >> 16 & 0xff;
            _package[6] = _endpoint_iterator->endpoint().address().to_v4().to_ulong() >> 8 & 0xff;
            _package[7] = _endpoint_iterator->endpoint().address().to_v4().to_ulong() & 0xff;
            _package[8] = 0;
            _package[9] = '\0';
            do_resolve();
        }
        void do_dst_resolve() {
            ip::tcp::resolver resolver1(global_io_service);
            _endpoint_iterator = resolver1.resolve({_host, _port});
            do_package();
        }
        
        void do_resolve() {
            ip::tcp::resolver resolver(global_io_service);
            _endpoint_iterator = resolver.resolve({_sock, _sock_port});
            do_connect();
        }

        void do_connect() {
            auto self(shared_from_this());
            boost::asio::async_connect(_socket, _endpoint_iterator,
                    [self, this](boost::system::error_code ec, ip::tcp::resolver::iterator) 
                    {
                        if (!ec) do_send_req();
                    });
        }

        void do_send_req() {
            auto self(shared_from_this());
            _socket.async_send(
                    buffer(_package, 10),
                    [this, self](boost::system::error_code ec, size_t len) {    
                    cout << "sentsize" << len << endl;
                    if (ec) {
                            cout << "[Error] Send Error." << endl;
                        } else {
                            do_read_rpy();
                        }
                    });
            
        }

        void do_read_rpy() {
            auto self(shared_from_this());
            _socket.async_read_some(
                buffer(_data, max_length),
                [this, self](boost::system::error_code ec, std::size_t len)
                {
                    cout << "recvsize" << len << endl;
                    if (!ec) {
                        do_read();
                    }
                });
            
        }

        void do_read() {
            auto self(shared_from_this());
            _socket.async_read_some(
                buffer(_data, max_length),
                [this, self](boost::system::error_code ec, std::size_t length)
                {
                    string str(_data.data(), length);
                    //escape(str);
                    //cout << str;
                    output_shell("s" + to_string(_num), str);
                    if (ec) {
                        cout << "[Error] Read Error." << endl;
                    } else if (str.find("% ") != string::npos) {
                        do_send_cmd();
                    } else {
                        do_read();
                    }
                });
        }
        void do_send_cmd() {
//            string _send_msg;
            getline(_infile, _send_msg);
            _send_msg = _send_msg + "\n";
            output_command("s" + to_string(_num), _send_msg);
            //cout << _send_msg << endl;
            auto self(shared_from_this());
            _socket.async_send(
                    buffer(_send_msg, _send_msg.size()),
                    [this, self](boost::system::error_code ec, size_t) {
                        if (ec) {
                            cout << "[Error] Send Error." << endl;
                        } else {
                            do_read();
                        }
                    });
        }
};

struct conn_info {
    int num = 0;
    string host, port, file;
};

void escape(string &data)
{
    boost::replace_all(data, "&",  "&amp;");
    boost::replace_all(data, "\"", "&quot;");
    boost::replace_all(data, "\'", "&apos;");
    boost::replace_all(data, "<",  "&lt;");
    boost::replace_all(data, ">",  "&gt;");
    boost::replace_all(data, "\n", "&NewLine;");
    boost::replace_all(data, "\r", "");
}

void output_shell(string session, string content) {
    escape(content);
    //cout << session <<": " << content <<endl;
    printf("<script>document.getElementById('%s').innerHTML += '%s';</script>\n", session.c_str(), content.c_str());
    fflush(stdout);
}

void output_command(string session, string content) {
    escape(content);
    printf("<script>document.getElementById('%s').innerHTML += '<b>%s</b>';</script>\n", session.c_str(), content.c_str());
    fflush(stdout);
}

int main(int, char* const[], char* const envp[]) {
    vector<conn_info> conn;
    string sock = "";
    string sock_port = "";

    cout << "Content-type: text/html" << endl << endl;
    printf(
    "    <!DOCTYPE html>\n"
    "    <html lang=\"en\">\n"
    "      <head>\n"
    "        <meta charset=\"UTF-8\" />\n"
    "        <title>NP Project 3 Console</title>\n"
    "        <link\n"
    "          rel=\"stylesheet\"\n"
    "          href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\"\n"
    "          integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\"\n"
    "          crossorigin=\"anonymous\"\n"
    "        />\n"
    "        <link\n"
    "          href=\"https://fonts.googleapis.com/css?family=Source+Code+Pro\"\n"
    "          rel=\"stylesheet\"\n"
    "        />\n"
    "        <link\n"
    "          rel=\"icon\"\n"
    "          type=\"image/png\"\n"
    "          href=\"https://cdn0.iconfinder.com/data/icons/small-n-flat/24/678068-terminal-512.png\"\n"
    "        />\n"
    "        <style>\n"
    "          * {\n"
    "            font-family: 'Source Code Pro', monospace;\n"
    "            font-size: 1rem !important;\n"
    "          }\n"
    "          body {\n"
    "            background-color: #212529;\n"
    "          }\n"
    "          pre {\n"
    "            color: #cccccc;\n"
    "          }\n"
    "          b {\n"
    "            color: #ffffff;\n"
    "          }\n"
    "        </style>\n"
    "      </head>\n"
    "      <body>\n"
    "        <table class=\"table table-dark table-bordered\">\n"
    "          <thead>\n"
    "            <tr>\n"
    );

    string q_str[5][3];
    for (int i = 0; i < 5; i ++) {
        for (int j = 0; j < 3; j++) {
            q_str[i][j] = "";
        }   
    }

    char *data = (char *)malloc(200);
   
    data = getenv("QUERY_STRING");
    string data_s = string(data).substr(3);
    size_t end;
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++) {
            end = data_s.find("&");
		    q_str[i][j] = data_s.substr(0, end);
            cout << i << " " << j<<q_str[i][j] <<endl;
            data_s = data_s.substr(end + 4);
        }
    }

    cout << "000000" <<endl;
    end = data_s.find("&");
    sock = data_s.substr(0, end);
    sock_port = data_s.substr(end + 4);

    //q_str[4][2] = data_s;
    
    for (int i = 0; i < 5; i++) {
        if (q_str[i][0] != "" && q_str[i][1] != "" && q_str[i][2] != "") {
            conn_info c;
            c.host = q_str[i][0];
            c.port = q_str[i][1];
            c.file = q_str[i][2];
            c.num = i + 1;
            conn.push_back(c);
        }
    }
    
    for (size_t i = 0; i < conn.size(); i++) {
        printf("<th scope=\"col\">%s:%s</th>\n", conn[i].host.c_str(), conn[i].port.c_str());
    }

    printf(
    "        </tr>\n"
    "      </thead>\n"
    "      <tbody>\n"
    "        <tr>\n"
    );

    for (size_t i = 0; i < conn.size(); i++) {
        printf("<td><pre id=\"s%i\" class=\"mb-0\"></pre></td>\n", conn[i].num);
    }

    printf(
    "       </tr>\n"
    "      </tbody>\n"
    "    </table>\n"
    "  </body>\n"
    "</html>\n"
    );

    cout << conn.size() << endl;;
    for (size_t i = 0; i < conn.size(); i++) {
        cout << "session" << endl;
        make_shared<Session>(conn[i].host, conn[i].port, conn[i].file, conn[i].num, sock, sock_port) -> start();
    }
    global_io_service.run();
    return 0;
}
