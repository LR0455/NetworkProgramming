#include "npshell.h"

using namespace std;
using namespace boost::asio;

struct client{
    string host_name, port, file_name, id, sid, hid;

    client(){}
    client(string hn, string pt, string fn, int clt_id)
    {
        host_name = hn;
        port = pt;
        file_name = fn;
        id = to_string(clt_id);
        sid = "s" + id; // be used output msg to correspond client
        hid = "h" + id;
    }
};
vector<client> clients;

void parse_query_string(string query){
    smatch reg_container;
    regex reg_ptn("([^&]+=([^&]+))+");

    string host_name, port, file_name;
    int count = 0;

    while (regex_search(query, reg_container, reg_ptn)) 
    {
        host_name = reg_container[2].str();
        query = reg_container.suffix().str();
        
        regex_search(query, reg_container, reg_ptn);
        port = reg_container[2].str();
        query = reg_container.suffix().str();
        
        regex_search(query, reg_container, reg_ptn);
        file_name = reg_container[2].str();
        query = reg_container.suffix().str();
        
        clients.push_back( client(host_name, port, file_name, count) );
        count ++;
    }

    #if dbg
    for (int i = 0 ; i < clients.size() ; i ++)
    {
        cout << "client" << i << ":\n";
        cout << "host_name:" << clients[i].host_name << endl;
        cout << "port:" << clients[i].port << endl;
        cout << "file_name:" << clients[i].file_name << endl;
    }
    #endif
}

void print_msg_to_client(int flag, string id, string msg) {
    // escaping HTML
    boost::replace_all(msg,"\r\n","&NewLine;");
    boost::replace_all(msg,"\n","&NewLine;");
    boost::replace_all(msg,"<","&lt;");
    boost::replace_all(msg,">","&gt;");
    if (flag == SHELL_FLAG)
    {
        // document.getElementById('s0').innerHTML += msg;
        cout << "<script>document.getElementById('" << id << "').innerHTML += '" << msg << "';</script>" << endl;
        fflush(stdout);
    }
    if (flag == CMD_FLAG)
    {
        cout << "<script>document.getElementById('" << id << "').innerHTML += '<b>" << msg << "</b>';</script>" << endl;
        fflush(stdout);
    }
}

io_service np_io_service;

class NPSession : public enable_shared_from_this<NPSession> {
    private:
        enum { max_length = 1024 };
        ip::tcp::socket np_socket;
        ip::tcp::resolver np_resolver;
        ip::tcp::resolver::query np_query;

        client np_client;

        array<char, max_length> read_data;

        ifstream fin;

    public:
        NPSession(client clt):np_socket(np_io_service), 
                              np_resolver(np_io_service),
                              np_query(ip::tcp::v4(), clt.host_name, clt.port),
                              np_client(clt) {}
        void start() 
        {
            print_msg_to_client(SHELL_FLAG, np_client.hid, np_client.host_name + ":" + np_client.port);
            fin.open("test_case/" + np_client.file_name);
            resolve_handler();
        }

    private:
        void resolve_handler()
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            np_resolver.async_resolve (np_query, 
                                      [this, np_shared_ptr] (const boost::system::error_code &ec,
                                                             ip::tcp::resolver::iterator resolver_it)
                                      {
                                          if (!ec)
                                              connect_handler(resolver_it);
                                          else
                                              np_socket.close();
                                      });
        }
        void connect_handler(ip::tcp::resolver::iterator resolver_it)
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            np_socket.async_connect (*resolver_it, 
                                    [this, np_shared_ptr] (const boost::system::error_code &ec)
                                    {
                                        if (!ec)
                                            read_handler();
                                        else
                                            np_socket.close();
                                    });
        }
        void read_handler()
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            np_socket.async_read_some ( buffer(read_data, max_length), 
                                        [this, np_shared_ptr] (const boost::system::error_code &ec,
                                                               size_t read_data_length)
                                        {
                                            if (!ec)
                                            {
                                                string msg(read_data.begin(), read_data.begin() + read_data_length);
                                                print_msg_to_client(SHELL_FLAG, np_client.sid, msg);
        
                                                if (msg.find("% ") != -1)
                                                    send_handler();
                                                else
                                                    read_handler();
                                            }
                                            else
                                                np_socket.close();
                                        });

        }
        void send_handler()
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            string line;
            getline(fin, line);
            line += "\n";
            print_msg_to_client(CMD_FLAG, np_client.sid, line);
            np_socket.async_send(buffer(line),
                                [this, np_shared_ptr] (const boost::system::error_code &ec,
                                                       size_t read_data_length)
                                {
                                    if (!ec)
                                        read_handler();
                                    else
                                        np_socket.close();
                                });
        }
};


void connect() {
    try 
    {
        for (int i = 0 ; i < clients.size() ; i ++) 
            make_shared<NPSession>(clients[i])->start();
            
        np_io_service.run();
    } 
    catch (exception& e) 
    {
        cerr << "Exception: " << e.what() << "\n";
    }

}

int main(){
    /* [Required] HTTP Header */
    cout << "Content-type: text/html" << endl << endl;
    char* query_string = getenv("QUERY_STRING");
    string query(query_string);
    
    cout << INIT_HTML;
    parse_query_string(query);

    connect();
}