#include "npshell.h"

using namespace std;
using namespace boost::asio;

io_service np_io_service;

class ServerSession : public enable_shared_from_this<ServerSession> {
    private:
        enum { max_length = 1024 };
        ip::tcp::socket np_socket;
        array<char, max_length> read_data;
        map<string, string> env;
        string file_name;

    public:
        ServerSession(ip::tcp::socket socket):np_socket(move(socket)) {}
        void start(){ read_handler(); }

    private:
        void read_handler()
        {
            shared_ptr<ServerSession> np_shared_ptr(shared_from_this());
            np_socket.async_read_some ( buffer(read_data, max_length), 
                                        [this, np_shared_ptr] (const boost::system::error_code &ec,
                                                               size_t read_data_length)
                                        {
                                            if (!ec)
                                            {
                                                string request(read_data.begin(), read_data.begin() + read_data_length);
                                                //cout << request << "\n";
                                                parse_request(request);
                                                child_handler();
                                            }
                                            else
                                                np_socket.close();
                                        });

        }
        void parse_request(string req)
        {      
            smatch reg_container;
            regex reg_ptn(REG_URL_PATTERN), reg_host_ptn(REG_HOST_PATTERN);
            
            if (regex_search(req, reg_container, reg_ptn)) 
            {   
                // for (int i = 0 ; i < reg_container.size() ; i ++)
                // {
                //     cout << reg_container[i] << endl;
                //     cout << "###########################\n";
                // }
                    
                
                env["REQUEST_METHOD"] = reg_container[1].str();
                env["REQUEST_URI"] = reg_container[2].str();
                env["QUERY_STRING"] = reg_container[4].str();
                env["SERVER_PROTOCOL"] = reg_container[5].str();

                file_name = "." + reg_container[3].str();

                regex_search(req, reg_container, reg_host_ptn);
                env["HTTP_HOST"] = reg_container[1].str();
                
                env["SERVER_ADDR"] = np_socket.local_endpoint().address().to_string();
                env["SERVER_PORT"] = to_string(np_socket.local_endpoint().port());
                env["REMOTE_ADDR"] = np_socket.remote_endpoint().address().to_string();
                env["REMOTE_PORT"] = to_string(np_socket.remote_endpoint().port());
            }       
        }
        void child_handler()
        {
            int pid;
            
            np_io_service.notify_fork(boost::asio::io_service::fork_prepare);
            
            pid = fork();
            if(pid == 0)
            {
                np_io_service.notify_fork(boost::asio::io_service::fork_child);
                np_setenv();
                
                dup2(np_socket.native_handle(), 0);
                dup2(np_socket.native_handle(), 1);
                dup2(np_socket.native_handle(), 2);
                np_socket.close();
                
                cout << "HTTP/1.1 200 OK" << endl;
                
                if (execvp(file_name.c_str(), NULL) == -1) 
                {
                    cout << "HTTP/1.1 200 OK"<<endl;
                    cout << "Content-type: text/html" << endl << endl;
                    cout << "<h1>123456789</h1>" << endl;
                }
                
            }
            else
            {
                np_io_service.notify_fork(boost::asio::io_service::fork_parent);
                np_socket.close();
            }

        }
        void np_setenv()
        {
            for (map<string, string>::iterator iter = env.begin() ; iter != env.end() ; iter ++)
                setenv(iter->first.c_str(), iter->second.c_str(), 1);
        }
};

class HTTPServer {
    private:
        ip::tcp::endpoint np_endpoint;
        ip::tcp::acceptor np_acceptor;
        ip::tcp::socket np_socket;

    public:
        HTTPServer(short port):np_socket(np_io_service),
                               np_endpoint(ip::tcp::v4(), port),
                               np_acceptor(np_io_service, np_endpoint) {}
        void start() 
        { 
            accept_handler(); 
            np_io_service.run();
        }
    
    private:
        void accept_handler()
        {
            np_acceptor.async_accept (np_socket, [this](const boost::system::error_code &ec)
                                                {
                                                    if (!ec)
                                                    {
                                                        make_shared<ServerSession>(move(np_socket))->start();
                                                        accept_handler();
                                                    }   
                                                    else
                                                        np_socket.close(); 
                                                });
           
        }
    
};
void signal_handle(int signo){
    int status;
    while (waitpid (-1, &status, WNOHANG) > 0);
}
int main(int argc, char *argv[]) {
    if (argc != 2) 
    {
        cout << "give me a port\n";
        return 1;
    }
    
    signal(SIGCHLD, signal_handle);
    clearenv();
    setenv("PATH", "/usr/bin:.", 1);
    
    try
    {
        short port = atoi(argv[1]);
        HTTPServer server(port);
        server.start();
    }
    catch (exception& e) 
    {
        cerr << "Exception: " << e.what() << "\n";
    }
    
    return 0;
    
}