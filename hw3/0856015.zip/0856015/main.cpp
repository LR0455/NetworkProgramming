#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <ctype.h>

// boost
#include <boost/asio.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/asio/io_service.hpp>
#include <boost/asio/write.hpp>
#include <boost/asio/buffer.hpp>
#include <boost/asio/ip/tcp.hpp>

// c++
#include <regex>
#include <fstream>
#include <array>
#include <string>
#include <iostream>
#include <sstream>
#include <errno.h>
#include <map>
#include <vector>
using namespace std;
using namespace boost::asio;


// ---------------- define -------------------------
# define CMD_FLAG 1
# define SHELL_FLAG 2

# define REG_URL_PATTERN "(.*) (((?:.*)cgi)(?:\\?(.*))?) (.*)"
# define REG_HOST_PATTERN "Host: (.*):"
# define REG_QUERY_PATTERN "([^&]+=([^&]+))+"

std::string INIT_HTML =
    R"(<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>NP Project 3 Console</title>
        <link
        rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
        crossorigin="anonymous"
        />
        <link
        href="https://fonts.googleapis.com/css?family=Source+Code+Pro"
        rel="stylesheet"
        />
        <link
        rel="icon"
        type="image/png"
        href="https://cdn0.iconfinder.com/data/icons/small-n-flat/24/678068-terminal-512.png"
        />
        <style>
        * {
            font-family: 'Source Code Pro', monospace;
            font-size: 1rem !important;
        }
        body {
            background-color: #212529;
        }
        pre {
            color: #cccccc;
        }
        b {
            color: #ffffff;
        }
        </style>
    </head>
    <body>
        <table class="table table-dark table-bordered">
        <thead>
            <tr>
            <th><pre id="h0" class="mb-0"></pre></th>
            <th><pre id="h1" class="mb-0"></pre></th>
            <th><pre id="h2" class="mb-0"></pre></th>
            <th><pre id="h3" class="mb-0"></pre></th>
            <th><pre id="h4" class="mb-0"></pre></th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td><pre id="s0" class="mb-0"></pre></td>
            <td><pre id="s1" class="mb-0"></pre></td>
            <td><pre id="s2" class="mb-0"></pre></td>
            <td><pre id="s3" class="mb-0"></pre></td>
            <td><pre id="s4" class="mb-0"></pre></td>
            </tr>
        </tbody>
        </table>
    </body>
    </html>)";
// -------------------------------------------------

io_service np_io_service;
//class NPSession;
class ServerSession;

struct client {
    string host_name, port, file_name, id, sid, hid;

    client(){}
    client(string hn, string pt, string fn, int clt_id)
    {
        host_name = hn;
        port = pt;
        file_name = fn;
        id = to_string(clt_id);
        sid = "s" + id; // be used output msg to correspond client
        hid = "h" + id;
    }
};

string print_msg_to_client(int flag, string id, string msg) {
    // escaping HTML
    boost::replace_all(msg,"\r\n","&NewLine;");
    boost::replace_all(msg,"\n","&NewLine;");
    boost::replace_all(msg,"<","&lt;");
    boost::replace_all(msg,">","&gt;");
    if (flag == SHELL_FLAG)
    {
        // document.getElementById('s0').innerHTML += msg;
        return "<script>document.getElementById('" + id + "').innerHTML += '" + msg + "';</script>\r\n";
    }
    if (flag == CMD_FLAG)
    {
        return "<script>document.getElementById('" + id + "').innerHTML += '<b>" + msg + "</b>';</script>\r\n";
    }
	return NULL;
}
// console.cgi
class NPSession : public enable_shared_from_this<NPSession> {
    private:
        enum { max_length = 1024 };
        ip::tcp::socket np_socket;
        ip::tcp::resolver np_resolver;
        ip::tcp::resolver::query np_query;

        client np_client;
        array<char, max_length> read_data;
        ifstream fin;

        shared_ptr<ServerSession> server_ptr;
        ip::tcp::socket &client_socket;

    public:
        NPSession(client clt, 
                  ip::tcp::socket &sock,
                  shared_ptr<ServerSession> ptr):np_socket(np_io_service), 
                                                 np_resolver(np_io_service),
                                                 np_query(ip::tcp::v4(), clt.host_name, clt.port),
                                                 np_client(clt),
                                                 client_socket(sock),
                                                 server_ptr(ptr){}
                                                 
        void start() 
        {
            string content = print_msg_to_client(CMD_FLAG, np_client.hid, np_client.host_name + ":" + np_client.port);
            client_send_handler(content);
            fin.open("test_case/" + np_client.file_name);
            resolve_handler();
        }

    private:
        void resolve_handler()
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            np_resolver.async_resolve (np_query, 
                                      [this, np_shared_ptr] (const boost::system::error_code &ec,
                                                             ip::tcp::resolver::iterator resolver_it)
                                      {
                                          if (!ec)
                                              connect_handler(resolver_it);
                                          else
                                              np_socket.close();
                                      });
        }
        void connect_handler(ip::tcp::resolver::iterator resolver_it)
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            np_socket.async_connect (*resolver_it, 
                                    [this, np_shared_ptr] (const boost::system::error_code &ec)
                                    {
                                        if (!ec)
                                            read_handler();
                                        else
                                            np_socket.close();
                                    });
        }
        void read_handler()
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            np_socket.async_read_some ( buffer(read_data, max_length), 
                                        [this, np_shared_ptr] (const boost::system::error_code &ec,
                                                               size_t read_data_length)
                                        {
                                            if (!ec)
                                            {
                                                string msg(read_data.begin(), read_data.begin() + read_data_length);
                                                string content = print_msg_to_client(SHELL_FLAG, np_client.sid, msg);
                                                client_send_handler(content);
                                                if (msg.find("% ") != -1)
                                                    send_handler();
                                                else
                                                    read_handler();
                                            }
                                            else
                                                np_socket.close();
                                        });

        }
        void send_handler()
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            string line;
            getline(fin, line);
            line += "\n";
            string content = print_msg_to_client(CMD_FLAG, np_client.sid, line);
            client_send_handler(content);
            np_socket.async_send(buffer(line),
                                [this, np_shared_ptr] (const boost::system::error_code &ec,
                                                       size_t read_data_length)
                                {
                                    if (!ec)
                                        read_handler();
                                    else
                                        np_socket.close();
                                });
        }
        void client_send_handler(string content)
        {
            shared_ptr<NPSession> np_shared_ptr(shared_from_this());
            client_socket.async_send (buffer(content), [this, np_shared_ptr] (const boost::system::error_code ec, 
                                                                          size_t length)
                                                    {
                                                        if (!ec)
                                                        {

                                                        }
                                                    });
        }
};

// http server
class ServerSession : public enable_shared_from_this<ServerSession> {
    private:
        enum { max_length = 1024 };
        ip::tcp::socket np_socket;
        array<char, max_length> read_data;
        map<string, string> env;
        string file_name;
        vector<client> clients;

    public:
        ServerSession(ip::tcp::socket socket):np_socket(move(socket)) {}
        void start(){ read_handler(); }

    private:
        void read_handler()
        {
            shared_ptr<ServerSession> np_shared_ptr(shared_from_this());
            np_socket.async_read_some ( buffer(read_data, max_length), 
                                        [this, np_shared_ptr] (const boost::system::error_code &ec,
                                                               size_t read_data_length)
                                        {
                                            if (!ec)
                                            {
                                                string request(read_data.begin(), read_data.begin() + read_data_length);
                                                parse_request(request);
                                            }
                                            else
                                                np_socket.close();
                                        });

        }
        void send_handler(string content)
        {
            shared_ptr<ServerSession> np_shared_ptr(shared_from_this());
            np_socket.async_send (buffer(content), [this, np_shared_ptr] (const boost::system::error_code ec, 
                                                                          size_t length)
                                                    {
                                                        if (!ec)
                                                        {

                                                        }
                                                    });
        }
        void exec_panel()
        {  
            int N_SERVERS = 5;
            string FORM_METHOD = "GET";
            string FORM_ACTION = "console.cgi";
            string TEST_CASE_DIR = "test_case";
            string test_cases[10] = {"t1.txt", "t2.txt", "t3.txt", "t4.txt", "t5.txt",
                                    "t6.txt", "t7.txt", "t8.txt", "t9.txt", "t10.txt"};
            
            string test_case_menu = "";
            for (int i = 0 ; i < 10 ; i ++)
                test_case_menu += "<option value=" + test_cases[i] + ">" + test_cases[i] + "</option>";
            
            string NPDOMAIN = "cs.nctu.edu.tw";
            string hosts[12] = {};
            for (int i = 0 ; i < 12 ; i ++)
                hosts[i] = "nplinux" + to_string(i + 1);
            
            string host_menu = "";
            for (int i = 0 ; i < 12 ; i ++)
                host_menu += "<option value=" + hosts[i] + "." + NPDOMAIN + ">" + hosts[i] + "</option>"; 
            
            string html = "";
            html += "HTTP/1.1 200 OK\r\n";
            html += "Content-type: text/html\r\n\r\n";
            
            html += R"(
               <!DOCTYPE html>
                <html lang="en">
                <head>
                    <title>NP Project 3 Panel</title>
                    <link
                    rel="stylesheet"
                    href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
                    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
                    crossorigin="anonymous"
                    />
                    <link
                    href="https://fonts.googleapis.com/css?family=Source+Code+Pro"
                    rel="stylesheet"
                    />
                    <link
                    rel="icon"
                    type="image/png"
                    href="https://cdn4.iconfinder.com/data/icons/iconsimple-setting-time/512/dashboard-512.png"
                    />
                    <style>
                    * {
                        font-family: 'Source Code Pro', monospace;
                    }
                    </style>
                </head>
                <body class="bg-secondary pt-5">)";
            
            html += "<form action=" + FORM_ACTION + " method=" + FORM_METHOD + ">";
            html += R"(
                <table class="table mx-auto bg-light" style="width: inherit">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Host</th>
                    <th scope="col">Port</th>
                    <th scope="col">Input File</th>
                </tr>
                </thead>
                <tbody>)";
            for (int i = 0 ; i < N_SERVERS ; i ++)
            {
                html += "<tr>";
                html += "<th scope='row' class='align-middle'>Session " + to_string(i + 1) + "</th>";
                html += R"(
                    <td>
                    <div class='input-group'>)";
                html += "<select name='h" + to_string(i) + "' class='custom-select'>";
                html += "<option></option>" + host_menu;
                html += R"(
                    </select>
                    <div class="input-group-append">
                    <span class="input-group-text">.cs.nctu.edu.tw</span>
                    </div>
                </div>
                </td>
                <td>)";
                html += "<input name='p" + to_string(i) + "' type='text' class='form-control' size='5' />";
                html += R"(
                    </td>
                    <td>)";
                html += "<select name='f" + to_string(i) + "' class='custom-select'>";
                html += "<option></option>";
                html += test_case_menu;
                html += R"(
                    </select>
                    </td>
                </tr>)";
            }
            html += R"(
                <tr>
                    <td colspan="3"></td>
                    <td>
                    <button type="submit" class="btn btn-info btn-block">Run</button>
                    </td>
                </tr>
                </tbody>
            </table>
            </form>
        </body>
        </html>)";
           
            send_handler(html);        
        }
        void exec_console()
        {
            /* [Required] HTTP Header */
            send_handler("HTTP/1.1 200 OK\r\n");
            send_handler("Content-type: text/html\r\n\r\n");

            string query = env["QUERY_STRING"];
            
            send_handler(INIT_HTML);
            parse_query_string(query);
            /*
            for (int i = 0 ; i < clients.size() ; i ++)
                cout << clients[i].host_name << ' ' << clients[i].port << endl;

            //connect(move(np_socket), clients);
            for (int i = 0 ; i < clients.size() ; i ++) 
                make_shared<NPSession>(clients[i], shared_from_this())->start();
            */
        }
        void parse_request(string req)
        {      
            smatch reg_container;
            regex reg_ptn(REG_URL_PATTERN), reg_host_ptn(REG_HOST_PATTERN);
            
            if (regex_search(req, reg_container, reg_ptn)) 
            {   
                /*
                for (int i = 0 ; i < reg_container.size() ; i ++)
                {
                    cout << reg_container[i] << endl;
                    cout << "###########################\n";
                }
                */
                file_name = "." + reg_container[3].str();
                if (file_name == "./panel.cgi")
                {
                    exec_panel();
                    return;
                }
                    
                env["REQUEST_METHOD"] = reg_container[1].str();
                env["REQUEST_URI"] = reg_container[2].str();
                env["QUERY_STRING"] = reg_container[4].str();
                env["SERVER_PROTOCOL"] = reg_container[5].str();

                regex_search(req, reg_container, reg_host_ptn);
                env["HTTP_HOST"] = reg_container[1].str();
                
                env["SERVER_ADDR"] = np_socket.local_endpoint().address().to_string();
                env["SERVER_PORT"] = to_string(np_socket.local_endpoint().port());
                env["REMOTE_ADDR"] = np_socket.remote_endpoint().address().to_string();
                env["REMOTE_PORT"] = to_string(np_socket.remote_endpoint().port());
            }      
            exec_console(); 
        }
        void parse_query_string(string query){
            smatch reg_container;
            regex reg_ptn("([^&]+=([^&]+))+");

            string host_name, port, file_name;
            int count = 0;

            while (regex_search(query, reg_container, reg_ptn)) 
            {
                host_name = reg_container[2].str();
                query = reg_container.suffix().str();
                
                regex_search(query, reg_container, reg_ptn);
                port = reg_container[2].str();
                query = reg_container.suffix().str();
                
                regex_search(query, reg_container, reg_ptn);
                file_name = reg_container[2].str();
                query = reg_container.suffix().str();
                
                //clients.push_back( client(host_name, port, file_name, count) );
                client clt(host_name, port, file_name, count);
                make_shared<NPSession>(clt, np_socket, shared_from_this())->start();
                count ++;
            }
        }
        
};

class HTTPServer {
    private:
        ip::tcp::endpoint np_endpoint;
        ip::tcp::acceptor np_acceptor;
        ip::tcp::socket np_socket;

    public:
        HTTPServer(short port):np_socket(np_io_service),
                               np_endpoint(ip::tcp::v4(), port),
                               np_acceptor(np_io_service, np_endpoint) {}
        void start() 
        { 
            accept_handler(); 
            np_io_service.run();
        }
    
    private:
        void accept_handler()
        {
            np_acceptor.async_accept (np_socket, [this](const boost::system::error_code &ec)
                                                {
                                                    if (!ec)
                                                    {
                                                        make_shared<ServerSession>(move(np_socket))->start();
                                                        accept_handler();
                                                    }   
                                                    else
                                                        np_socket.close(); 
                                                });
           
        }
    
};

int main(int argc, char *argv[]) {
    if (argc != 2) 
    {
        cout << "give me a port\n";
        return 1;
    }
	
    try
    {
        short port = atoi(argv[1]);
        HTTPServer server(port);
        server.start();
    }
    catch (exception& e) 
    {
        cerr << "Exception: " << e.what() << "\n";
    }
    
    return 0;
    
}