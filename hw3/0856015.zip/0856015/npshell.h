// ------------------- include --------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <vector>
#include <ctype.h>
#include <string>
#include <iostream>
#include <sstream>
#include <errno.h>
#include <map>

#include <netdb.h> 
#include <netinet/in.h> 
#include <sys/socket.h> 
#include <arpa/inet.h>
#include <sys/mman.h>

#include <boost/asio.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/asio/io_service.hpp>
#include <boost/asio/write.hpp>
#include <boost/asio/buffer.hpp>
#include <boost/asio/ip/tcp.hpp>

#include <regex>
#include <fstream>
#include <array>
// -------------------------------------------------
// ---------------- define -------------------------
# define MAX_PIPE 4000
# define MAX_CMD_INPUT 20000
# define MAX_CLIENTS 50
# define print(output, fd) write(fd, output, strlen(output));

# define CMD_FLAG 1
# define SHELL_FLAG 2

# define REG_URL_PATTERN "(.*) (((?:.*)cgi)(?:\\?(.*))?) (.*)"
# define REG_HOST_PATTERN "Host: (.*):"
# define REG_QUERY_PATTERN "([^&]+=([^&]+))+"

std::string INIT_HTML =
    R"(<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>NP Project 3 Console</title>
        <link
        rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
        crossorigin="anonymous"
        />
        <link
        href="https://fonts.googleapis.com/css?family=Source+Code+Pro"
        rel="stylesheet"
        />
        <link
        rel="icon"
        type="image/png"
        href="https://cdn0.iconfinder.com/data/icons/small-n-flat/24/678068-terminal-512.png"
        />
        <style>
        * {
            font-family: 'Source Code Pro', monospace;
            font-size: 1rem !important;
        }
        body {
            background-color: #212529;
        }
        pre {
            color: #cccccc;
        }
        b {
            color: #ffffff;
        }
        </style>
    </head>
    <body>
        <table class="table table-dark table-bordered">
        <thead>
            <tr>
            <th><pre id="h0" class="mb-0"></pre></th>
            <th><pre id="h1" class="mb-0"></pre></th>
            <th><pre id="h2" class="mb-0"></pre></th>
            <th><pre id="h3" class="mb-0"></pre></th>
            <th><pre id="h4" class="mb-0"></pre></th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td><pre id="s0" class="mb-0"></pre></td>
            <td><pre id="s1" class="mb-0"></pre></td>
            <td><pre id="s2" class="mb-0"></pre></td>
            <td><pre id="s3" class="mb-0"></pre></td>
            <td><pre id="s4" class="mb-0"></pre></td>
            </tr>
        </tbody>
        </table>
    </body>
    </html>)";
// -------------------------------------------------
void user_close();
