1. basic printenv and setenv
2. ordinay pipe
3. setenv correctly
4. |N
5. merge pipe
6. !N
7. Redirect to file (overwrite existing file)
8. Unknown command behavior
9. Newline does not count as one line
10. Multiple arguments
11. many ordinay pipe
12. Big Jump
13. Many |N
14. Large data
15. Large with many |N
