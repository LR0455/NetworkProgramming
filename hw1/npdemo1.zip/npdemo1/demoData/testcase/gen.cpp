#include <iostream>
using namespace std;
int main() {
  for (int i = 150; i > 0; i--) {
    cout << "ls |" << i << endl;
  }
  cout << "blackhole" << endl;
  cout << "exit" << endl;
  return 0;
}
